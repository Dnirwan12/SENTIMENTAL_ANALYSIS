
import nltk
nltk.download()